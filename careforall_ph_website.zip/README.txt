CareForAll PH website

Preview: open index.html in a browser.

To make a QR code that works for everyone, publish this folder using a static website host such as GitHub Pages or Netlify. Then create a QR code from the public HTTPS URL. A QR code pointing to a file only on your device will not work for other people.

Review the content and links before public use.
